package testProcess;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class ProcessorClass implements Processor {

	public void process(Exchange ex) throws Exception{
		System.out.println("Processor Class...");
		
	}
	
}
