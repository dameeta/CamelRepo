package testRoute;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;

import testProcess.ProcessorClass;

public class MyRouter extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
	
		from("file:/myfiles/old?noop=true").process(new ProcessorClass()).to("file:/newFolder"); 

}}
