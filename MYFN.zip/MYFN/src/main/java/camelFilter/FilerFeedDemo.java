package camelFilter;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class FilerFeedDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		CamelContext camelctx= new DefaultCamelContext();
		try {
			
			camelctx.addRoutes(new RouteBuilder() {

				@Override
				public void configure() throws Exception {
					// TODO Auto-generated method stub
		from("atom:file:src/main/resources/feed.atom?splitEntries=true&consumer.delay=1000").to("seda:feeds");
		
		from("seda:feeds")
		.filter()
		.method(new CamelData(),"filter" )
		.to("seda:filteredData");
		from("seda:filteredData").to("stream:out");
		
				}
						
				
			});
			camelctx.start();
			Thread.sleep(5000);
		}
		
		
		finally {
			
			camelctx.stop();
		}
		
	}

}
