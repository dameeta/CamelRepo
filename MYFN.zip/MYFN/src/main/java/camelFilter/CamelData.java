package camelFilter;

import org.apache.abdera.*;
import org.apache.abdera.model.Entry;
import org.apache.camel.Exchange;

public class CamelData  {

	public boolean filter(Exchange exh)
	{
		Entry entry=exh.getIn().getBody(Entry.class);
		String title=entry.getTitle();
		boolean cameldata =title.toLowerCase().startsWith("java");
		if(cameldata)
		{
			
			System.out.println("Printed  title"+ title);
			
		}
		return cameldata ;
		
		
	}
}
