package MainApp;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class RouteMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext ctx=new ClassPathXmlApplicationContext("route.xml");
		
		ctx.start();
		System.out.println("Context initialized..");
		
		try {
			Thread.sleep(5*500*2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			
			ctx.stop();
			ctx.close();
		}
	}

}
