package basicfilecopy;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class fileCopy {

	//Java DSL
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CamelContext context =new DefaultCamelContext();
		System.out.println("\n == Executing File Copying ==");
		try {
			context.addRoutes(new RouteBuilder() {

				@Override
				public void configure() throws Exception {
					// TODO Auto-generated method stub

					from("file:data/inbox?noop=true").to("file:data/outbox");
				}
			});
			
			System.out.println("\n == File Copying started");
			context.start();
			Thread.sleep(10000);
			context.stop();
			System.out.println("\n == File Copied ==");
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}